//= require_tree ./catarse_wepay

$(function(){
  app.createViewGetters();
});
