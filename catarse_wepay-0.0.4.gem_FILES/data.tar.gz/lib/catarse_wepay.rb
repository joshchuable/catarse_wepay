require 'wepay'
require "catarse_wepay/engine"
require "catarse_wepay/payment_engine"

module CatarseWepay
end
