module CatarseWepay
  class Engine < ::Rails::Engine
    isolate_namespace CatarseWepay
  end
end

