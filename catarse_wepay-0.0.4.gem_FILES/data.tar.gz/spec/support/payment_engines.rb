# dummy class to be stubbed should use interface defined in Catarse
class PaymentEngines
end
