Rails.application.routes.draw do

  mount CatarseWepay::Engine => "/catarse_wepay"
end
